class  car implements vehcile{

public void start(){
	
	System.out.println("engine start .....");
	
}
 public void stop(){
		System.out.println("engine stop .....");
	
	

}

}