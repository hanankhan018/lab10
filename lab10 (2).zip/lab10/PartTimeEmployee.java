public class PartTimeEmployee extends Employee implements TaxPayer {


    double hourlyRate;

    int hoursWorked;

    public PartTimeEmployee(String name, int id, double hourlyRate, int hoursWorked) {

        super(name, id);

        this.hourlyRate = hourlyRate;

        this.hoursWorked = hoursWorked;

    }

    
    double calculateSalary() {
        return hourlyRate * hoursWorked;

    }

    

    public void payTax() {
        double tax = calculateSalary() * 0.1;
        
        System.out.println(name + " pays tax: $" + tax);
    }
}
