interface vehcile{



 public void start();
 public void stop();



}