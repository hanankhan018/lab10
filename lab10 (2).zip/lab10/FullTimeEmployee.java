class FullTimeEmployee extends Employee implements TaxPayer {

    double monthlySalary;

    public FullTimeEmployee(String name, int id, double monthlySalary) {

        super(name, id);

        this.monthlySalary = monthlySalary;

    }

    
    double calculateSalary() {

        return monthlySalary;
    }

    
    public void payTax() {

        double tax = calculateSalary() * 0.2;

        System.out.println(name + " pays tax: $" + tax);
    }
}
