class main{




public static void main(String []args){
	
	
	dog d = new dog();
	cat ca = new cat();
	d.Eat();
	d.makesound();
	ca.makesound();
    System.out.println("task 2");
	car c = new car();
    bike b = new bike();
	c.start();
	b.start();
	c.stop();
	b.stop();
	System.out.println("task3");
	rectangle r = new rectangle();
	System.out.println("area of rectangle :"+r.area(2.5,7.6));
	r.print();
	
	System.out.println("task4");
	duck d1 = new duck();
	d1.fly();
	d1.swim();
	
} 

}