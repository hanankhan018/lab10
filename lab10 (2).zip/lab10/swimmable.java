interface swimmable{






} 