abstract class shape {


abstract double area(double length , double height);
}