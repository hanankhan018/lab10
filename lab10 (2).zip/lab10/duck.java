class duck implements flyable , swimmable{


public void fly(){
	
	System.out.println("hanan ura ura... ");
	
	
}
public void swim(){
	
	System.out.println("shahood kali machli pani ma chapak");
	
	
}



}