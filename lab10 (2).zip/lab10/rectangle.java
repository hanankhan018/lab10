 class rectangle extends shape implements printable{

double area(double length , double height){
	
	return length*height;
	
	
	
}
public void print(){
	System.out.println("hanan ka 9 marks cheating ka bad bhi");
}





}