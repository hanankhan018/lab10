class dog extends Animal{


void makesound(){
	
	System.out.println("Bark  Bark.....");
	
	
}








}