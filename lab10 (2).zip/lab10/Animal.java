abstract class Animal{

 abstract void makesound();

 void Eat(){
	 
	 System.out.println("Animal is eating....... ");
	 
	 
 }
}