 interface TaxPayer {
    
    void payTax();
}
